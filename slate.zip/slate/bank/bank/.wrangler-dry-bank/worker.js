var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// worker.mjs
import { DurableObject } from "cloudflare:workers";

// ledger.mjs
function fmt(minor) {
  return `$${(minor / 100).toLocaleString("en-US", { minimumFractionDigits: minor % 100 ? 2 : 0 })}`;
}
__name(fmt, "fmt");
function rand(len) {
  const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
  const bytes = new Uint8Array(len);
  crypto.getRandomValues(bytes);
  let s = "";
  for (const b of bytes) s += alphabet[b % alphabet.length];
  return s;
}
__name(rand, "rand");
function createLedger(initial = null) {
  const accounts = new Map(initial?.accounts?.map((a) => [a.id, a]) ?? []);
  const transactions = initial?.transactions ?? [];
  let seq = initial?.seq ?? 0;
  let next = initial?.next ?? 31877402;
  function openAccount(holder) {
    const clean = String(holder || "").trim().slice(0, 24) || "Account holder";
    const acc = {
      id: `br-${String(next++)}`,
      holder: clean,
      sort: "40-11-27",
      secret: rand(24),
      balance: 25e4,
      openedAt: Date.now()
    };
    accounts.set(acc.id, acc);
    return acc;
  }
  __name(openAccount, "openAccount");
  function auth(id, secret) {
    const acc = accounts.get(String(id || ""));
    return acc && secret && acc.secret === secret ? acc : null;
  }
  __name(auth, "auth");
  function publicView(acc) {
    return { id: acc.id, holder: acc.holder, sort: acc.sort };
  }
  __name(publicView, "publicView");
  function transfer({ from, secret, to, amount, reference }) {
    const src = auth(from, secret);
    const dst = accounts.get(String(to || ""));
    if (!src) return { ok: false, message: "That account or secret is not right." };
    if (!dst) return { ok: false, message: `No account ${to} at this bank.` };
    if (src === dst) return { ok: false, message: "Cannot transfer to the same account." };
    const minor = Math.round(Number(amount) * 100);
    if (!Number.isFinite(minor) || minor <= 0) return { ok: false, message: "Amount must be a positive number." };
    if (src.balance < minor) {
      return { ok: false, message: `Insufficient funds: ${src.holder} has ${fmt(src.balance)}, transfer is ${fmt(minor)}.` };
    }
    const ref = String(reference || "").trim().slice(0, 40);
    src.balance -= minor;
    dst.balance += minor;
    const tx = {
      id: `tx_${(++seq).toString(36)}`,
      at: Date.now(),
      from: src.id,
      fromHolder: src.holder,
      to: dst.id,
      toHolder: dst.holder,
      amount: minor,
      reference: ref
    };
    transactions.push(tx);
    if (transactions.length > 2e3) transactions.shift();
    return { ok: true, message: `Sent ${fmt(minor)} to ${dst.holder} (${dst.id})${ref ? `, ref ${ref}` : ""}.`, transaction: tx };
  }
  __name(transfer, "transfer");
  function list(acc, reference) {
    let out = transactions.filter((t) => t.from === acc.id || t.to === acc.id);
    if (reference) out = out.filter((t) => t.reference === reference);
    return out.slice(-50).reverse();
  }
  __name(list, "list");
  function snapshot() {
    return { accounts: [...accounts.values()], transactions, seq, next };
  }
  __name(snapshot, "snapshot");
  return { openAccount, auth, publicView, transfer, list, accounts, snapshot };
}
__name(createLedger, "createLedger");
async function handleApi(url, request, ledger, config) {
  const cors = {
    "Access-Control-Allow-Origin": config.partner,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    Vary: "Origin"
  };
  const json = /* @__PURE__ */ __name((status, body) => new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...cors }
  }), "json");
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (url.pathname === "/api/config") return json(200, { partner: config.partner, name: "Bramble Bank" });
  if (url.pathname === "/api/accounts" && request.method === "POST") {
    let body;
    try {
      body = await request.json();
    } catch {
      return json(400, { ok: false, message: "Malformed body." });
    }
    const acc = ledger.openAccount(body?.holder);
    return json(200, { ok: true, account: { id: acc.id, secret: acc.secret, holder: acc.holder, sort: acc.sort } });
  }
  let m = /^\/api\/accounts\/([^/]+)\/public$/.exec(url.pathname);
  if (m && request.method === "GET") {
    const acc = ledger.accounts.get(decodeURIComponent(m[1]));
    return acc ? json(200, { ok: true, account: ledger.publicView(acc) }) : json(404, { ok: false, message: "No such account." });
  }
  m = /^\/api\/accounts\/([^/]+)$/.exec(url.pathname);
  if (m && request.method === "GET") {
    const acc = ledger.auth(decodeURIComponent(m[1]), url.searchParams.get("secret"));
    if (!acc) return json(403, { ok: false, message: "That account or secret is not right." });
    return json(200, { ok: true, account: { id: acc.id, holder: acc.holder, sort: acc.sort, balance: acc.balance } });
  }
  if (url.pathname === "/api/transactions" && request.method === "GET") {
    const acc = ledger.auth(url.searchParams.get("account"), url.searchParams.get("secret"));
    if (!acc) return json(403, { ok: false, message: "That account or secret is not right." });
    return json(200, { transactions: ledger.list(acc, url.searchParams.get("reference")) });
  }
  if (url.pathname === "/api/transfer" && request.method === "POST") {
    let body;
    try {
      body = await request.json();
    } catch {
      return json(400, { ok: false, message: "Malformed body." });
    }
    const result = ledger.transfer(body);
    return json(result.ok ? 200 : 422, result);
  }
  return null;
}
__name(handleApi, "handleApi");

// worker.mjs
var BankLedger = class extends DurableObject {
  static {
    __name(this, "BankLedger");
  }
  async fetch(request) {
    if (!this.ledger) {
      const saved = await this.ctx.storage.get("ledger");
      this.ledger = createLedger(saved ?? null);
    }
    const url = new URL(request.url);
    const partner = (this.env.BANK_PARTNER_ORIGIN || "http://localhost:3000").replace(/\/$/, "");
    const res = await handleApi(url, request, this.ledger, { partner });
    if (!res) return new Response("Not found", { status: 404 });
    if (request.method === "POST") await this.ctx.storage.put("ledger", this.ledger.snapshot());
    return res;
  }
};
var worker_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      const stub = env.LEDGER.get(env.LEDGER.idFromName("bramble"));
      return stub.fetch(request);
    }
    return env.ASSETS.fetch(request);
  }
};
export {
  BankLedger,
  worker_default as default
};
//# sourceMappingURL=worker.js.map
